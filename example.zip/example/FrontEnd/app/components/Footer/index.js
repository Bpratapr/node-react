/**
*
* Footer
*
*/

import React from 'react';


class Footer extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <footer>
          <div className="container text-center">  </div>
      </footer>
    );
  }
}

export default Footer;
