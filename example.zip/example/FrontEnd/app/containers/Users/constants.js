/*
 *
 * Users constants
 *
 */

export const DEFAULT_ACTION = 'app/Users/DEFAULT_ACTION';
